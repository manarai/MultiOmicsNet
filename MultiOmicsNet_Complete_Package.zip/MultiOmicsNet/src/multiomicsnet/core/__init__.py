"""Core modules for MultiOmicsNet."""

from .integrator import MultiOmicsIntegrator

__all__ = ['MultiOmicsIntegrator']

